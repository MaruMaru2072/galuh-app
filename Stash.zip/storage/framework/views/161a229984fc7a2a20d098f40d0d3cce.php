<?php $__env->startSection('content'); ?>
    <div class="input-group mt-5 ms-5" style="width: 90%">
        <form action="/searchResultPage" method="post" class="w-100 d-flex">
            <?php echo csrf_field(); ?>
            <input type="textarea" class="form-control" aria-describedby="button-addon2" name="search">
            <button class="btn btn-outline-secondary" type="submit">&#x1F50D</button>
        </form>
    </div>
    <div class="body mt-2 ms-5">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="percategory mt-3 pb-4">

                <div class="category d-flex pb-2 pt-2">
                    <p class="mb-0 ps-3 pe-2"><?php echo e($category->name); ?></p>
                    <a href="/categoryPage/<?php echo e($category->id); ?>" style="text-decoration:none;">View All</a>
                </div>

                <div class="scrollmenu" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->category_id == $category->id && $item->is_visible == true): ?>
                            <div class="card pt-1" style="width: 20vw; height: 35vh; display: inline-block;">
                                <a href="/productDetailPage/<?php echo e($item->id); ?>">
                                    <img class="card-img-top img-thumbnail object-fit-cover border rounded"
                                         src="<?php echo e(asset($item->photourl)); ?>" style="width: 20vw; height: 25vh"
                                         alt="Item Image">
                                    <div class="card-body">
                                        <h5 class="card-title"
                                            style="
                                                    width: 15vw;
                                                    overflow: hidden;
                                                    white-space: nowrap;
                                                    text-overflow: ellipsis;
                                                "><?php echo e($item->name); ?></h5>
                                        <p class="card-text">Rp.<?php echo e($item->price); ?></p>
                                    </div>
                                </a>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elvissusanto/PhpstormProjects/galuh-app/resources/views/store/index.blade.php ENDPATH**/ ?>