<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h1>Forum Pecinta Hewan</h1>

    <div class="d-flex justify-content-between mb-4">
        <form method="GET" action="<?php echo e(route('forum.index')); ?>" class="d-flex flex-grow-1 me-2">
            <input type="text" name="title" class="form-control me-2" placeholder="Search by title" value="<?php echo e(request('title')); ?>">
            <select name="category" class="form-control me-2">
                <option value="">Select Category</option>
                <option value="Pet Carer">Pet Carer</option>
                <option value="Pet Product">Pet Product</option>
                <option value="Fact About Pet">Fact About Pet</option>
                <option value="General Discussion">General Discussion</option>
            </select>
            <input type="date" name="from_date" class="form-control me-2" value="<?php echo e(request('from_date')); ?>">
            <input type="date" name="to_date" class="form-control me-2" value="<?php echo e(request('to_date')); ?>">
            <button type="submit" class="btn btn-primary me-2">Search</button>
        </form>

        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('forum.create')); ?>" class="btn btn-success">Create Forum</a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-success">Create Forum</a>
        <?php endif; ?>
    </div>

    <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title"><a href="<?php echo e(route('forum.show', $forum->id)); ?>"><?php echo e($forum->title); ?></a></h5>
                <p class="card-text"><?php echo e($forum->content); ?></p>
                <p class="card-text"><small class="text-muted">By <?php echo e($forum->user->name); ?> on <?php echo e($forum->created_at->format('d M Y')); ?></small></p>
                <p class="card-text"><small class="text-muted">Category: <?php echo e($forum->category); ?></small></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elvissusanto/PhpstormProjects/galuh-app/resources/views/forum/index.blade.php ENDPATH**/ ?>