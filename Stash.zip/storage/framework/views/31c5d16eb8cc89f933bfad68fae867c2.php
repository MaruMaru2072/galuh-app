<?php $__env->startSection('content'); ?>
<div class="body mt-2 ms-5" style="width: 93%">
    <div class="percategory mt-3 pb-4">
        <div class="category d-flex pb-2 pt-2">
            <p class="mb-0 ps-3 pe-2">Category <?php echo e($category->name); ?></p>
        </div>
        <div class="prodparentcategory d-flex">
            <?php $__currentLoopData = $categoriedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->category_id == $category->id): ?>
                    <a href="/productDetailPage/<?php echo e($item->id); ?>" class="prodlist">
                    <div class="card">
                        <img src="<?php echo e(asset($item->photourl)); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                          <p class="card-text"><?php echo e($item->name); ?></p>
                          <h6 class="card-price">IDR <?php echo e($item->price); ?></h6>
                        </div>
                      </div>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="mt-3 d-flex justify-content-end" style="width: 100%">
        <?php echo e($categoriedItems ->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elvissusanto/PhpstormProjects/galuh-app/resources/views/store/category.blade.php ENDPATH**/ ?>