<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">
        <?php if(session('success')): ?>
            <b><?php echo e(Session::get('success')); ?></b>
        <?php else: ?>
            <p></p>
        <?php endif; ?>
        <button id="scroll-to-bottom-button" type="button" class="btn btn-primary">Create new category</button>
    </div>

    <script>
        document.getElementById("scroll-to-bottom-button").addEventListener("click", function () {
            document.body.scrollIntoView({behavior: "smooth", block: "end"});
        });
    </script>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="body mt-2">
            <div class="d-flex justify-content-center">
                <div class="managelist">
                    <div class="d-flex" style="background-color: white; width: 70vw;">
                        <div class="managetitle ms-4 mt-4">

                            <h5 class="card-text"><b><?php echo e($category->name); ?></b></h5>
                            <div class="editcategory">
                                <form method="POST" action="/updateCategory/<?php echo e($category->id); ?>"
                                      class="d-flex justify-content-between pb-4">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </form>
                            </div>

                        </div>
                        <div class="d-flex mt-4 me-3 justify-content-end" style="width: 100%">
                            <form action="/deleteCategory/<?php echo e($category->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="managebtn btn btn-outline-danger">&#128465</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <form method="post" action="/createCategory" class="d-flex justify-content-between pb-4 pt-4">
        <?php echo csrf_field(); ?>
        <input type="text" class="form-control" name="name" placeholder="Type new category.." required>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elvissusanto/PhpstormProjects/galuh-app/resources/views/store/categoryeditor.blade.php ENDPATH**/ ?>