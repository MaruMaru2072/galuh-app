<?php $__env->startSection('content'); ?>

    <div class="input-group d-flex justify-content-center" style="width: 90%">
        <form action="/searchResultPage" method="post" class="w-100 d-flex">
            <?php echo csrf_field(); ?>
            <input type="textarea" class="form-control" aria-describedby="button-addon2" name="search"
                   value=<?php echo e($searched->search); ?>>
            <button class="btn btn-outline-secondary" type="submit">&#x1F50D</button>
        </form>
    </div>

    <div class="d-flex justify-content-center pt-3">
        <?php if($q->isEmpty()): ?>
            <p class="text-secondary">No such items contains "<?php echo e($searched->search); ?>"</p>
        <?php else: ?>
            <p class="text-secondary">Showing search results for items containing "<?php echo e($searched->search); ?>"</p>
        <?php endif; ?>
    </div>

    <div class="percategory mt-3 pb-4">

        <div class="scrollmenu" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

            <?php $__currentLoopData = $q; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->is_visible): ?>
                    <a href="/productDetailPage/<?php echo e($item->id); ?>">
                        <div class="card pt-1" style="width: 20vw; height: 35vh; display: inline-block;">
                            <img class="card-img-top img-thumbnail object-fit-cover border rounded"
                                 src="<?php echo e(asset($item->photourl)); ?>" style="width: 20vw; height: 25vh" alt="Item Image">
                            <div class="card-body">
                                <h5 class="card-title"
                                    style="
                                                        width: 15vw;
                                                          overflow: hidden;
                                                        white-space: nowrap;
                                                        text-overflow: ellipsis;
                                                    "><?php echo e($item->name); ?></h5>
                                <p class="card-text">Rp.<?php echo e($item->price); ?></p>
                            </div>

                        </div>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elvissusanto/PhpstormProjects/galuh-app/resources/views/store/search.blade.php ENDPATH**/ ?>