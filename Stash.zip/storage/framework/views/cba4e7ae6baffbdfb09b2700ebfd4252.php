<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $historyheader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item m-auto mt-3 w-50">
                <h2 class="accordion-header" id="flush-heading<?php echo e($hh->id); ?>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#flush-collapse<?php echo e($hh->id); ?>" aria-expanded="false"
                        aria-controls="flush-collapse<?php echo e($hh->id); ?>">
                        Transaction Date <?php echo e($hh->transactionDate); ?>

                    </button>
                </h2>
                <div id="flush-collapse<?php echo e($hh->id); ?>" class="accordion-collapse collapse"
                    aria-labelledby="flush-heading<?php echo e($hh->id); ?>" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Sub Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $hh->connectHistoryDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->connectItem->name); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e($item->qty * $item->connectItem->price); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <?php
                                    $totalqty=0;
                                    $totalprice=0;
                                    foreach ($hh->connectHistoryDetail as $cd) {
                                        $totalqty += $cd->qty;
                                        $totalprice += $cd->qty * $cd->connectItem->price;
                                    }
                                    ?>
                                    <th scope="col">Total</th>
                                    <th scope="col"><?php echo e($totalqty); ?> item(s)</th>
                                    <th scope="col">IDR <?php echo e($totalprice); ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elvissusanto/PhpstormProjects/galuh-app/resources/views/store/history.blade.php ENDPATH**/ ?>