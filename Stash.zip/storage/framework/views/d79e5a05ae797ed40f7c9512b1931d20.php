<head>
    <script type="text/javascript" src="https://sandbox.web.squarecdn.com/v1/square.js"></script>
</head>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $cartdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="d-flex">
            <div class="d-flex" style="background-color: white; width: 70vw;">
                <img src="<?php echo e(asset($product->connectItem->photourl)); ?>" style="max-height:35vh; max-width:15vw;"
                     class="manageimg" alt="...">
                <div class="managetitle ms-4 mt-4">
                    <a href="/productDetailPage/<?php echo e($product->connectItem->id); ?>">
                        <h5 class="card-title">
                            <u>
                                <?php echo e($product->connectItem->name); ?>

                            </u>
                        </h5>
                    </a>
                    <h6 class="card-subtitle mb-2 text-body-secondary">
                        Price: Rp. <?php echo e($product->qty * $product->connectItem->price); ?></h6>
                    <p class="card-text"><?php echo e($product->qty); ?> item(s)</p>
                </div>
                <div class="d-flex mt-4 me-3 justify-content-end" style="width: 100%">
                    <form action="/cartPage/<?php echo e($product->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" class="managebtn btn btn-outline-danger">&#128465</button>
                    </form>
                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <footer class="d-flex mt-3">
        <div class="d-flex align-items-center justify-content-center" style="background-color: white; width: 100vw;">
            <?php if(count($cartdetail)): ?>
                <p class="mt-3">Total price: Rp. <?php echo e($totalPrice); ?></p>
            <?php else: ?>
                <p class="mt-3">No items in cart yet!</p>
            <?php endif; ?>
        </div>
    </footer>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elvissusanto/PhpstormProjects/galuh-app/resources/views/store/cart.blade.php ENDPATH**/ ?>