<?php $__env->startSection('content'); ?>
    <div class="body mt-2 ms-5 d-flex justify-content-center align-items-center" style="height: 91vh">
        <div class="detailparent p-3">

            <div class="card d-flex align-items-left" style="width: 30vw;">
                <img src="<?php echo e(asset($items->photourl)); ?>"
                     class="card-img-top img-thumbnail object-fit-cover border rounded" alt="Item Image">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($items->name); ?></h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">Rp. <?php echo e($items->price); ?></h6>
                    <p class="card-text"><?php echo e($items->detail); ?></p>
                    <form action="/cartPage" method="post">
                        <?php echo csrf_field(); ?>
                        <p class="detailtitle"> Qty</p>
                        <input name="quantity" type="number" class="form-control" id="inputqty">
                        <input name="itemid" value="<?php echo e($items->id); ?>" type="hidden">
                        <button type="submit" class="btn btn-outline-dark detailchild mt-3">Purchase</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/elvissusanto/PhpstormProjects/galuh-app/resources/views/store/itemdetail.blade.php ENDPATH**/ ?>