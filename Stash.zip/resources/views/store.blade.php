@extends('layout')
@section('content')
<h1>Storepage</h1>
<p>Details of the store.</p>
@endsection
